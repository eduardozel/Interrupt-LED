/*
**
**                           Main.c
**
**
**********************************************************************/
/*
   Last committed:     $Revision: 00 $
   Last changed by:    $Author: $
   Last changed date:  $Date:  $
   ID:                 $Id:  $

**********************************************************************/

#include <stm32f10x_conf.h>

#define RCC1_GPIO RCC_APB2Periph_GPIOA
#define RCC2_GPIO RCC_APB2Periph_GPIOB

#define LED_PORT GPIOB
#define LEDgrn_PIN GPIO_Pin_10
#define LEDred_PIN GPIO_Pin_11

#define BTNgrn_PORT GPIOA
#define BTNred_PORT GPIOB

#define BTNred_PIN GPIO_Pin_12
#define BTNgrn_PIN GPIO_Pin_8

int WATERcnt = 0;

void EXTI9_5_IRQHandler(void){
  if (EXTI_GetITStatus(EXTI_Line8) != RESET){
    WATERcnt++;
    if ( GPIO_ReadInputDataBit( BTNgrn_PORT, BTNgrn_PIN ) ) { // ( BTN_PORT->IDR & BTN1_PIN )
      GPIO_ResetBits( LED_PORT , LEDgrn_PIN);
    } else {
      GPIO_SetBits( LED_PORT, LEDgrn_PIN);
    } // if
    EXTI_ClearITPendingBit(EXTI_Line8);
  }; // if
}; // EXTI9_5_IRQHandler


void EXTI15_10_IRQHandler(void){
  if (EXTI_GetITStatus(EXTI_Line12) != RESET){
    WATERcnt++;
    if ( GPIO_ReadInputDataBit( BTNred_PORT, BTNred_PIN ) ) {
      GPIO_ResetBits( LED_PORT , LEDred_PIN);
    } else {
      GPIO_SetBits( LED_PORT, LEDred_PIN);
    } // if
    EXTI_ClearITPendingBit(EXTI_Line12);
  }; // if
}; // EXTI15_10_IRQHandler

void Delay(volatile uint32_t nCount) {
for (; nCount != 0; nCount--);
}

int main(void) {
/* SystemInit() startup_stm32f10x_md_vl.c */

RCC_APB2PeriphClockCmd(RCC1_GPIO, ENABLE);
RCC_APB2PeriphClockCmd(RCC2_GPIO, ENABLE);

GPIO_InitTypeDef GPIO_InitStructure;
GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;

GPIO_InitStructure.GPIO_Pin = LEDgrn_PIN | LEDred_PIN;
GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;

GPIO_Init( LED_PORT, &GPIO_InitStructure );

GPIO_InitStructure.GPIO_Pin = BTNred_PIN;
GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
GPIO_Init( BTNred_PORT, &GPIO_InitStructure );

GPIO_InitStructure.GPIO_Pin = BTNgrn_PIN;
GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
GPIO_Init( BTNgrn_PORT, &GPIO_InitStructure );


    RCC_APB2PeriphClockCmd(RCC_APB2ENR_AFIOEN, ENABLE);

    EXTI_InitTypeDef exti;
      GPIO_EXTILineConfig( GPIO_PortSourceGPIOB, GPIO_PinSource12);
      exti.EXTI_Line = EXTI_Line12;
      exti.EXTI_Mode = EXTI_Mode_Interrupt;
      exti.EXTI_Trigger = EXTI_Trigger_Rising_Falling; //
      exti.EXTI_LineCmd = ENABLE;
      EXTI_Init(&exti);

      GPIO_EXTILineConfig( GPIO_PortSourceGPIOA, GPIO_PinSource8);
      exti.EXTI_Line = EXTI_Line8;
      exti.EXTI_Mode = EXTI_Mode_Interrupt;
      exti.EXTI_Trigger = EXTI_Trigger_Rising_Falling; //
      exti.EXTI_LineCmd = ENABLE;
      EXTI_Init(&exti);

    NVIC_InitTypeDef nvic;
      nvic.NVIC_IRQChannel = EXTI9_5_IRQn;
      nvic.NVIC_IRQChannelPreemptionPriority = 2;
      nvic.NVIC_IRQChannelSubPriority = 2;
      nvic.NVIC_IRQChannelCmd = ENABLE;
      NVIC_Init(&nvic);

      nvic.NVIC_IRQChannel = EXTI15_10_IRQn;
      nvic.NVIC_IRQChannelPreemptionPriority = 2;
      nvic.NVIC_IRQChannelSubPriority = 2;
      nvic.NVIC_IRQChannelCmd = ENABLE;
      NVIC_Init(&nvic);

    PWR_EnterSTANDBYMode();

while (1) {
} // while
return 0;
}
